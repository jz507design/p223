# Licencias — Auditor de IA Local

Este documento resume la situación legal del producto. **Objetivo: código
100% original + dependencias open source permisivas, sin pagar ninguna
licencia y sin restricciones para revender el producto a empresas.**

## 1. Código propio

Todo el código fuente en `src/auditor_ia/` es **original de JZ Design
Solutions**, escrito desde cero para este producto. No contiene código
copiado de otros proyectos, ni dependencias de pago.

> Recomendación: registrar los derechos de autor del código ante la
> autoridad competente del país de venta (en México: INDAUTOR) y marcar
> cada archivo fuente con un encabezado de copyright.

## 2. Dependencias de runtime (todas permiten uso comercial sin costo)

| Paquete | Versión | Licencia | Uso en el producto |
|---|---|---|---|
| psutil | 7.2.2 | BSD-3-Clause | Escaneo de procesos |
| jinja2 | 3.1.6 | BSD-3-Clause | Plantillas de reportes |
| requests | 2.34.2 | Apache-2.0 | Cliente HTTP hacia Ollama |
| fastapi | 0.141.1 | MIT | API opcional |
| uvicorn | 0.52.0 | BSD-3-Clause | Servidor ASGI |
| playwright | 1.x | Apache-2.0 | Generación de PDF (Chromium) |
| presidio-analyzer | 2.2.364 | MIT | Detección de PII |
| presidio-anonymizer | 2.2.x | MIT | Anonimización de PII |
| spaCy (+ en_core_web_lg) | 3.8.x | MIT | NER para Presidio |
| pytest | 9.1.1 | MIT | Testing |

Todas las licencias anteriores (MIT, BSD-3-Clause, Apache-2.0, MPL-2.0)
permiten uso, modificación y **redistribución comercial**, incluso dentro
de un producto cerrado, siempre que se conserve el aviso de copyright
original de cada librería (los textos completos vienen dentro del paquete
instalado en `.venv/`).

> **Nota MPL-2.0** (`certifi`, `tqdm`): copyleft a nivel de archivo, no
> contamina el producto completo. Es la misma licencia que usa Firefox.
> Basta conservar el aviso del archivo/licencia en la distribución.

### Por qué NO se usa WeasyPrint
WeasyPrint arrastra `pyphen` (GPLv2+), que **contaminaría** el producto
obligando a liberar el código completo. Se sustituyó por **Playwright +
Chromium** (Apache-2.0 + BSD-3-Clause): misma calidad de PDF, cero
restricciones, y de paso elimina dependencias de sistema (GTK/Pango)
que complicaban la instalación en clientes.

## 3. Modelos de IA (CRÍTICO)

El motor de auditoría semántica depende de un modelo local servido por
Ollama. **La licencia del modelo NO es la del producto** — es de su
creador. Regla del producto:

| Modelo | Licencia | ¿Comercial libre? |
|---|---|---|
| DeepSeek-R1 (1.5b/7b/14b/32b Qwen) | MIT + Apache 2.0 | ✅ Sí |
| DeepSeek-R1 / V3.1 / V3.2 / V4 (oficial) | MIT | ✅ Sí |
| Mistral 7B / Mistral Nemo | Apache 2.0 | ✅ Sí |
| Qwen 2.5 (local) | Apache 2.0 | ✅ Sí |
| Phi-3 / Phi-3.5 | MIT | ✅ Sí |
| llama3 / llama3.1 / llama3.2 | Llama Community (Meta) | ⚠️ Condicionada (aprobación >700M MAU, cláusulas) |
| deepseek-r1:8b / :70b (distills Llama) | Llama (Meta) | ⚠️ Hereda licencia de Meta |
| Gemma | Gemma Terms (Google) | ⚠️ Condicionada |

**Decisión de producto:** el modelo por defecto es `deepseek-r1:7b`
(MIT / Apache 2.0 — derivado de Qwen, sin restricciones). El instalador
del producto debe documentar qué modelo viene incluido y su licencia.
Si el cliente trae su propio Ollama, el contrato debe aclarar que el
modelo es responsabilidad del cliente.

## 4. Herramientas externas

| Herramienta | Licencia | Nota |
|---|---|---|
| Ollama | MIT | Runtime gratuito, comercial libre |
| mitmproxy | MIT | Interceptor de tráfico (módulo en desarrollo) |
| Playwright | Apache-2.0 | Generación de PDF + testing de la UI de reportes |
| Chromium (navegador) | BSD-3-Clause | Motor de renderizado del PDF |

## 5. Reglas para el equipo (obligatorias)

1. **Nunca** añadir una dependencia sin verificar su licencia.
   Comando de chequeo: `.venv\Scripts\python scripts/check_licenses.py`.
2. Si una dependencia es GPL/AGPL/LGPL/SSPL o comercial: **rechazada** (GPL
   obliga a liberar el código del producto completo).
3. MPL-2.0 es aceptable (copyleft de archivo), conservando el aviso.
4. Modelos incluidos en la instalación: solo MIT o Apache 2.0.
5. No copiar fragmentos de código de Stack Overflow/GitHub sin reescribirlos
   sustancialmente y sin verificar su licencia.
6. **Nada en disco C:** todo runtime (venv, navegadores Playwright, modelos
   Ollama, cache pip, reportes, base de datos) vive en `D:\PROYECTO\.runtime`
   para no llenar el disco del sistema. Documentar en el instalador del
   cliente que debe existir un disco de datos con espacio suficiente.

## 6. Checklist pre-venta

- [ ] Ejecutar `scripts/check_licenses.py` y revisar que ninguna sea GPL/comercial.
- [ ] Listar modelos instalados y validar sus licencias.
- [ ] Conservar copia de los avisos de copyright de dependencias (pkg_resources).
- [ ] Incluir este documento en la carpeta legal del producto.
- [ ] Registrar el copyright del código propio (INDAUTOR en México).
