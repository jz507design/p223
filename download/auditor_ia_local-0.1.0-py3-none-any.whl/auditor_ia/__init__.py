"""P223 — Policia de IAs (Auditor de IA Local).

Escaneo de entorno, deteccion de PII/secretos y auditoria semantica local.
P223 remite a Proverbios 22:3: "El prudente ve el peligro y se protege".
"""

__version__ = "0.1.0"
