"""Escaneo de permisos en carpetas sensibles del usuario.

En Windows se evalúa la ACL con `icacls` buscando entradas tipo
"Everyone:(OI)(CI)(F)" o "BUILTIN\\Users:(F)" que indiquen acceso
abierto; en POSIX se revisan los bits de permisos de grupo y otros.
"""

from __future__ import annotations

import os
import stat
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

_WINDOWS_OPEN_PATTERNS = ("Everyone", "BUILTIN\\Users", "\\Users:")


@dataclass(frozen=True, slots=True)
class PermissionFinding:
    path: str
    exists: bool
    risk: str  # alto | medio | bajo


def _windows_weak(path: Path) -> bool:
    """Consulta la ACL con icacls y detecta entradas de acceso abierto."""
    try:
        result = subprocess.run(
            ["icacls", str(path)],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
    except (OSError, subprocess.SubprocessError):
        # Sin icacls disponible: asumimos riesgo medio (conservador)
        return True

    output = result.stdout or ""
    return any(pattern in output for pattern in _WINDOWS_OPEN_PATTERNS)


def _posix_weak(path: Path) -> bool:
    mode = path.stat().st_mode
    return bool(mode & (stat.S_IRWXG | stat.S_IRWXO))


def check_directory(path: Path) -> PermissionFinding:
    if not path.exists():
        return PermissionFinding(str(path), exists=False, risk="bajo")
    if not path.is_dir():
        return PermissionFinding(str(path), exists=True, risk="medio")

    if sys.platform == "win32":
        weak = _windows_weak(path)
    else:
        weak = _posix_weak(path)

    risk = "alto" if weak else "bajo"
    return PermissionFinding(str(path), exists=True, risk=risk)


def scan_sensitive_dirs(dirs: list[Path]) -> list[PermissionFinding]:
    return [check_directory(d) for d in dirs]
