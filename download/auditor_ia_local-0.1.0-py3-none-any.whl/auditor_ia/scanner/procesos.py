"""Escaneo de procesos en ejecucion.

Detecta procesos relacionados con IA local (ollama, lmstudio, etc.) y
procesos python que puedan estar sirviendo modelos o proxies.
"""

from __future__ import annotations

from dataclasses import dataclass

import psutil

from auditor_ia.config import IA_PROCESS_NAMES


@dataclass(frozen=True, slots=True)
class ProcessInfo:
    pid: int
    name: str
    cmdline: tuple[str, ...]
    is_ia_related: bool
    exe: str = ""


def _is_ia_related(name: str, cmdline: tuple[str, ...]) -> bool:
    """Determina si un proceso es de IA local.

    Reglas para evitar falsos positivos:
    - El propio proceso del auditor (contiene 'auditor_ia') nunca cuenta.
    - Se compara el NOMBRE del ejecutable con la lista de procesos IA.
    - En la linea de comandos se buscan palabras completas (no substrings),
      para que 'audit_with_ollama' no haga match con 'ollama'.
    """
    lowered = name.lower()
    if "auditor_ia" in lowered or "auditor_ia" in " ".join(cmdline).lower():
        return False
    if any(keyword in lowered for keyword in IA_PROCESS_NAMES):
        return True
    tokens = set()
    for part in cmdline:
        for token in part.lower().replace("\\", "/").replace("=", " ").split():
            tokens.add(token.strip("\"'"))
    return any(keyword in tokens for keyword in IA_PROCESS_NAMES)


def scan_processes() -> list[ProcessInfo]:
    """Lista los procesos activos, marcando los relacionados con IA local."""
    results: list[ProcessInfo] = []
    for proc in psutil.process_iter(["pid", "name", "cmdline", "exe"]):
        try:
            info = proc.info
            cmdline = tuple(info["cmdline"] or ())
            results.append(
                ProcessInfo(
                    pid=info["pid"],
                    name=info["name"] or "?",
                    cmdline=cmdline,
                    is_ia_related=_is_ia_related(info["name"] or "", cmdline),
                    exe=info["exe"] or "",
                )
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return results


def find_ia_processes() -> list[ProcessInfo]:
    """Solo procesos relacionados con IA local."""
    return [p for p in scan_processes() if p.is_ia_related]
