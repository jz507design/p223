"""Deteccion de claves de API expuestas en el entorno.

Revisa variables de entorno con nombres de claves conocidas y sugiere
si el valor parece un secreto real (heuristica basada en longitud y
entropia). Tambien escanea archivos de configuracion comunes en busca
de patrones tipo sk-..., ak..., etc.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass

from auditor_ia.config import SENSITIVE_VAR_NAMES

# Patrones comunes de claves API
_KEY_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b(sk-[A-Za-z0-9_\-]{20,})\b"),                 # OpenAI / DeepSeek
    re.compile(r"\b(api[_-]?key\s*[=:]\s*['\"]?[\w\-]{16,})", re.I),
    re.compile(r"\b(AKIA[0-9A-Z]{16})\b"),                       # AWS access key
    re.compile(r"\b(gh[pousr]_[A-Za-z0-9]{30,})\b"),             # GitHub tokens
    re.compile(r"\b(xox[baprs]-[A-Za-z0-9\-]{20,})\b"),          # Slack tokens
)


@dataclass(frozen=True, slots=True)
class SecretFinding:
    location: str  # "env" | "file"
    name: str
    masked_value: str
    risk: str  # alto | medio


def _mask(value: str) -> str:
    """Muestra solo los primeros 4 y ultimos 4 caracteres."""
    if len(value) <= 10:
        return "***"
    return f"{value[:4]}...{value[-4:]}"


def _looks_like_secret(value: str) -> bool:
    if len(value) < 16:
        return False
    return any(p.search(value) for p in _KEY_PATTERNS)


def scan_env_vars() -> list[SecretFinding]:
    """Revisa variables de entorno sensibles."""
    findings: list[SecretFinding] = []
    for var in SENSITIVE_VAR_NAMES:
        value = os.getenv(var, "")
        if not value:
            continue
        findings.append(
            SecretFinding(
                location="env",
                name=var,
                masked_value=_mask(value),
                risk="alto" if _looks_like_secret(value) else "medio",
            )
        )
    return findings


def scan_file(path: str | os.PathLike[str]) -> list[SecretFinding]:
    """Escanea un archivo de texto en busca de claves tipo API."""
    findings: list[SecretFinding] = []
    try:
        with open(path, encoding="utf-8", errors="ignore") as fh:
            content = fh.read()
    except OSError:
        return findings

    for pattern in _KEY_PATTERNS:
        for match in pattern.finditer(content):
            found = match.group(1)
            findings.append(
                SecretFinding(
                    location="file",
                    name=str(path),
                    masked_value=_mask(found),
                    risk="alto",
                )
            )
    return findings
