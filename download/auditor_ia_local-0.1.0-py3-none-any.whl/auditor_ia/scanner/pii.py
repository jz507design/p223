"""Deteccion y anonimizacion de PII con Microsoft Presidio.

Analiza texto (prompts, archivos de log, configuraciones) buscando
informacion personal: nombres, emails, telefonos, direcciones, IPs,
tarjetas, etc. Todo el procesamiento es local, sin enviar datos a la nube.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from presidio_analyzer import AnalyzerEngine, RecognizerResult
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

# Entidades PII soportadas por Presidio que nos interesan
PII_ENTITIES: tuple[str, ...] = (
    "PERSON",
    "EMAIL_ADDRESS",
    "PHONE_NUMBER",
    "CREDIT_CARD",
    "IP_ADDRESS",
    "LOCATION",
    "DATE_TIME",
    "NRP",
    "IBAN_CODE",
    "US_BANK_NUMBER",
    "US_SSN",
    "CRYPTO",
    "URL",
)

# Patrones extra de secretos que Presidio no cubre por defecto
_EXTRA_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b(sk-[A-Za-z0-9_\-]{20,})\b"),               # API keys
    re.compile(r"\b(Bearer\s+[A-Za-z0-9\-._~+/]{20,})\b", re.I),
    re.compile(r"\b(AKIA[0-9A-Z]{16})\b"),                     # AWS keys
    re.compile(r"\b(gh[pousr]_[A-Za-z0-9]{30,})\b"),           # GitHub tokens
)


@dataclass(frozen=True, slots=True)
class PiiFinding:
    entity: str
    start: int
    end: int
    score: float
    value: str


@dataclass(slots=True)
class PiiAnalysis:
    findings: list[PiiFinding]
    anonymized: str

    @property
    def count(self) -> int:
        return len(self.findings)

    @property
    def high_confidence(self) -> list[PiiFinding]:
        return [f for f in self.findings if f.score >= 0.5]


class PiiDetector:
    """Detector de PII reutilizable (carga los engines una sola vez)."""

    def __init__(self) -> None:
        self._analyzer: AnalyzerEngine | None = None
        self._anonymizer: AnonymizerEngine | None = None

    @property
    def analyzer(self) -> AnalyzerEngine:
        if self._analyzer is None:
            self._analyzer = AnalyzerEngine()
        return self._analyzer

    @property
    def anonymizer(self) -> AnonymizerEngine:
        if self._anonymizer is None:
            self._anonymizer = AnonymizerEngine()
        return self._anonymizer

    def analyze(self, text: str) -> list[PiiFinding]:
        """Detecta PII en un texto usando Presidio + patrones extra."""
        # Se usa language="en": Presidio solo tiene NER spaCy para ingles.
        # Los recognizers por patron (email, telefono, tarjeta, IP, etc.)
        # son independientes del idioma, y el NER reconoce nombres en
        # cualquier idioma con el modelo en_core_web_lg.
        results = self.analyzer.analyze(
            text=text,
            entities=list(PII_ENTITIES),
            language="en",
        )
        findings = [
            PiiFinding(
                entity=r.entity_type,
                start=r.start,
                end=r.end,
                score=float(r.score),
                value=text[r.start : r.end],
            )
            for r in results
        ]

        # Patrones extra de secretos (API keys, tokens)
        for pattern in _EXTRA_PATTERNS:
            for match in pattern.finditer(text):
                findings.append(
                    PiiFinding(
                        entity="SECRET",
                        start=match.start(1),
                        end=match.end(1),
                        score=1.0,
                        value=match.group(1),
                    )
                )

        return _dedupe_overlaps(findings)

    def anonymize(self, text: str) -> PiiAnalysis:
        """Anonimiza el texto reemplazando PII por placeholders."""
        findings = self.analyze(text)
        if not findings:
            return PiiAnalysis(findings=findings, anonymized=text)

        results = [
            RecognizerResult(
                entity_type=f.entity,
                start=f.start,
                end=f.end,
                score=f.score,
            )
            for f in findings
        ]
        anonymized = self.anonymizer.anonymize(
            text=text,
            analyzer_results=results,
            operators={"DEFAULT": OperatorConfig("replace", {"new_value": "<[REDACTADO]>"})},
        ).text
        return PiiAnalysis(findings=findings, anonymized=anonymized)


def _dedupe_overlaps(findings: list[PiiFinding]) -> list[PiiFinding]:
    """Elimina hallazgos solapados quedandose con el de mayor score.

    Presidio frecuentemente reporta NER y regex sobre la misma zona
    (ej. "juan.perez@empresa.com" como PERSON y como EMAIL). Se conserva
    el mas confiable; los empates se resuelven por longitud mayor.
    """
    if len(findings) <= 1:
        return findings
    ordered = sorted(findings, key=lambda f: (-f.score, -(f.end - f.start), f.start))
    kept: list[PiiFinding] = []
    for candidate in ordered:
        overlaps = any(
            not (candidate.end <= other.start or candidate.start >= other.end)
            for other in kept
        )
        if not overlaps:
            kept.append(candidate)
    return sorted(kept, key=lambda f: f.start)


def analyze_text(text: str) -> PiiAnalysis:
    """Funcion conveniente: analiza y anonimiza un texto en una llamada."""
    return PiiDetector().anonymize(text)
