"""Orquestador del escaneo de entorno.

Consolida los resultados de procesos, puertos, secretos y permisos en
un unico objeto AuditResult listo para el motor de auditoria.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from auditor_ia.config import Settings
from auditor_ia.scanner.permisos import PermissionFinding, scan_sensitive_dirs
from auditor_ia.scanner.pii import PiiFinding
from auditor_ia.scanner.procesos import ProcessInfo, scan_processes
from auditor_ia.scanner.puertos import PortInfo, scan_ports
from auditor_ia.scanner.secretos import SecretFinding, scan_env_vars


@dataclass(slots=True)
class AuditResult:
    """Resultado crudo de un escaneo de entorno."""

    timestamp: str
    processes: list[ProcessInfo] = field(default_factory=list)
    ports: list[PortInfo] = field(default_factory=list)
    secrets: list[SecretFinding] = field(default_factory=list)
    permissions: list[PermissionFinding] = field(default_factory=list)
    pii_findings: list[PiiFinding] = field(default_factory=list)

    @property
    def ia_processes(self) -> list[ProcessInfo]:
        return [p for p in self.processes if p.is_ia_related]

    @property
    def open_ports(self) -> list[PortInfo]:
        return [p for p in self.ports if p.state == "open"]

    @property
    def high_risk_count(self) -> int:
        return len(self.secrets) + sum(
            1 for p in self.permissions if p.risk == "alto"
        )


def summarize_result(result: AuditResult, lang: str = "es") -> str:
    """Resumen textual del escaneo para el motor de auditoria.

    Se usa tanto en el CLI como en el panel web para alimentar al modelo
    local. No incluye valores de secretos ni PII: el modelo recibe solo
    metadatos, asi no hay fuga hacia el propio prompt. El idioma de las
    etiquetas se ajusta con ``lang`` ("es" o "en").
    """
    es = lang != "en"
    ia_proc = "IA processes" if not es else "Procesos IA"
    open_ports = "Open ports" if not es else "Puertos abiertos"
    secrets = "Secrets" if not es else "Secretos"
    high_risk = "High risks" if not es else "Riesgos altos"
    secrets_detected = "Secrets detected" if not es else "Secretos detectados"
    critical_perms = "Critical permissions" if not es else "Permisos criticos"

    partes = [
        f"{ia_proc}: {len(result.ia_processes)}",
        f"{open_ports}: {len(result.open_ports)}",
        f"{secrets}: {len(result.secrets)}",
        f"{high_risk}: {result.high_risk_count}",
    ]
    if result.secrets:
        nombres = ", ".join(f"{s.location}:{s.name}" for s in result.secrets[:5])
        partes.append(f"{secrets_detected}: {nombres}")
    if result.permissions:
        criticos = [p.path for p in result.permissions if p.risk == "alto"]
        if criticos:
            partes.append(f"{critical_perms}: " + ", ".join(criticos[:5]))
    return "; ".join(partes)


def run_scan(settings: Settings) -> AuditResult:
    """Ejecuta el escaneo completo del entorno."""
    return AuditResult(
        timestamp=datetime.now(timezone.utc).isoformat(),
        processes=scan_processes(),
        ports=scan_ports(),
        secrets=scan_env_vars(),
        permissions=scan_sensitive_dirs(list(settings.sensitive_dirs)),
    )
