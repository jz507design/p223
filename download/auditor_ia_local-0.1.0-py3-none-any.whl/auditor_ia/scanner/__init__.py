"""Escaneo de entorno: procesos, puertos, secretos y permisos."""
