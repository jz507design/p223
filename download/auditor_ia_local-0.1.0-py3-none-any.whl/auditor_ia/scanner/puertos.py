"""Escaneo de puertos abiertos y exposicion de servicios de IA."""

from __future__ import annotations

import socket
from dataclasses import dataclass

from auditor_ia.config import IA_PORTS


@dataclass(frozen=True, slots=True)
class PortInfo:
    port: int
    service: str
    state: str  # open | closed


def _check_port(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.4)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def scan_ports() -> list[PortInfo]:
    """Comprueba los puertos conocidos de herramientas de IA locales."""
    return [
        PortInfo(port=port, service=name, state="open" if _check_port(port) else "closed")
        for port, name in IA_PORTS.items()
    ]


def open_ia_ports() -> list[PortInfo]:
    return [p for p in scan_ports() if p.state == "open"]
