"""Motor de auditoria semantica (modelos locales via Ollama)."""
