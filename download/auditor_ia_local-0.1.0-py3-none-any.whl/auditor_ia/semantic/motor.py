"""Motor de auditoria semantica.

Usa un modelo local via Ollama para evaluar hallazgos del escaneo y
detectar fugas de informacion o permisos excesivos. Nunca envia datos
a la nube.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

import requests

from auditor_ia.config import Settings


class OllamaUnavailableError(RuntimeError):
    """El servidor Ollama no esta respondiendo en la URL configurada."""


@dataclass(slots=True)
class AuditVerdict:
    summary: str
    risk_level: str  # bajo | medio | alto
    recommendations: list[str]
    raw: str = ""


def _build_prompt(result_summary: str) -> str:
    return (
        "Eres un auditor de seguridad de sistemas de IA local. "
        "Recibes un resumen del escaneo de entorno. Debes responder EXCLUSIVAMENTE "
        "con un objeto JSON, sin texto adicional, sin listar opciones. "
        'Formato: {"summary": "analisis breve", "risk_level": "bajo", '
        '"recommendations": ["recomendacion 1"]}. '
        "El campo risk_level DEBE ser una unica cadena: \"bajo\", \"medio\" o \"alto\" "
        "(solo uno, sin separadores ni llaves). "
        'Ejemplo valido: {"summary": "No se detectaron riesgos.", '
        '"risk_level": "bajo", "recommendations": ["Ninguna accion urgente."]}\n\n'
        f"Resumen del escaneo:\n{result_summary}"
    )


def check_ollama(settings: Settings) -> bool:
    """Comprueba que Ollama esta disponible (GET /api/tags)."""
    try:
        resp = requests.get(f"{settings.ollama_url}/api/tags", timeout=3)
        return resp.status_code == 200
    except requests.RequestException:
        return False


def _extract_json(raw: str) -> dict | None:
    """Extrae el primer objeto JSON del texto de salida del modelo.

    DeepSeek-R1 emite razonamiento dentro de tags <think>...</think>;
    el JSON puede ir antes, dentro o despues. Se busca el primer bloque
    { ... } balanceado y se intenta parsear.
    """
    start = raw.find("{")
    if start == -1:
        return None
    depth = 0
    for i in range(start, len(raw)):
        if raw[i] == "{":
            depth += 1
        elif raw[i] == "}":
            depth -= 1
            if depth == 0:
                candidate = raw[start : i + 1]
                try:
                    parsed = json.loads(candidate)
                    return parsed if isinstance(parsed, dict) else None
                except json.JSONDecodeError:
                    continue
    return None


def audit_with_ollama(settings: Settings, result_summary: str) -> AuditVerdict:
    """Consulta el modelo local y parsea su veredicto JSON."""
    if not check_ollama(settings):
        raise OllamaUnavailableError(
            f"Ollama no disponible en {settings.ollama_url}. "
            "Ejecuta 'ollama serve' antes de auditar."
        )

    payload = {
        "model": settings.auditor_model,
        "prompt": _build_prompt(result_summary),
        "stream": False,
        "format": "json",
    }
    resp = requests.post(
        f"{settings.ollama_url}/api/generate", json=payload, timeout=120
    )
    resp.raise_for_status()

    data = resp.json()
    raw = data.get("response", "")
    parsed = _extract_json(raw)
    if parsed is None:
        # Fallback conservador si el modelo no devolvio JSON valido
        return AuditVerdict(
            summary="El modelo no devolvio JSON valido. Revisar el modelo local.",
            risk_level="medio",
            recommendations=["Actualizar el modelo o reintentar la auditoria."],
            raw=raw,
        )

    risk_level = parsed.get("risk_level", "medio")
    if risk_level not in {"bajo", "medio", "alto"}:
        risk_level = "medio"

    return AuditVerdict(
        summary=parsed.get("summary", ""),
        risk_level=risk_level,
        recommendations=parsed.get("recommendations", []),
        raw=raw,
    )
