"""Configuracion central del auditor.

Los valores cargan primero desde variables de entorno (AUDITOR_*) y luego
desde el archivo config/settings.toml si existe. Nunca se hardcodean secretos.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
REPORTS_DIR = PROJECT_ROOT / "reports"
CONFIG_FILE = PROJECT_ROOT / "config" / "settings.toml"

# Procesos tipicamente asociados a modelos de IA locales
IA_PROCESS_NAMES: tuple[str, ...] = (
    "ollama",
    "lmstudio",
    "llama",
    "llama-server",
    "llamafile",
    "text-generation",
    "gpt4all",
)

# Puertos por defecto de herramientas de IA locales
IA_PORTS: dict[int, str] = {
    11434: "Ollama",
    1234: "LM Studio",
    5000: "Servidor OpenAI-compatible",
    8000: "API local comun",
}

# Variables de entorno que nunca deberian contener secretos en produccion
SENSITIVE_VAR_NAMES: tuple[str, ...] = (
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "AWS_SECRET_ACCESS_KEY",
    "AZURE_OPENAI_KEY",
    "GOOGLE_API_KEY",
    "HUGGINGFACE_TOKEN",
    "REPLICATE_API_TOKEN",
    "COHERE_API_KEY",
    "GEMINI_API_KEY",
    "MISTRAL_API_KEY",
    "GROQ_API_KEY",
    "DEEPSEEK_API_KEY",
)


@dataclass(slots=True)
class Settings:
    """Configuracion en runtime, con defaults seguros."""

    ollama_url: str = "http://127.0.0.1:11434"
    # Modelo por defecto: DeepSeek-R1 (licencia MIT, uso comercial sin
    # restricciones). Evitar modelos con licencias restringidas (ej.
    # llama3 de Meta, o los distills DeepSeek-R1 basados en Llama 8b/70b).
    # Variantes recomendadas: deepseek-r1:7b (Qwen, Apache 2.0), deepseek-r1:14b.
    auditor_model: str = "deepseek-r1:7b"
    scan_documents: bool = False
    sensitive_dirs: tuple[Path, ...] = field(
        default_factory=lambda: (Path.home() / ".ssh", Path.home() / ".aws")
    )
    report_format: str = "html"  # html | pdf
    db_path: Path = PROJECT_ROOT / "auditor.db"
    # Contrasena del panel web. Vacia = panel abierto (modo desarrollo).
    panel_password: str = ""
    # Secreto para firmar sesiones del panel. Si no se define, se genera
    # uno aleatorio en cada arranque (invalida sesiones al reiniciar).
    panel_secret: str = ""

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            ollama_url=os.getenv("AUDITOR_OLLAMA_URL", "http://127.0.0.1:11434"),
            auditor_model=os.getenv("AUDITOR_MODEL", "deepseek-r1:7b"),
            scan_documents=os.getenv("AUDITOR_SCAN_DOCUMENTS", "0") == "1",
            report_format=os.getenv("AUDITOR_REPORT_FORMAT", "html"),
            panel_password=os.getenv("AUDITOR_PANEL_PASSWORD", ""),
            panel_secret=os.getenv("AUDITOR_PANEL_SECRET", ""),
        )
