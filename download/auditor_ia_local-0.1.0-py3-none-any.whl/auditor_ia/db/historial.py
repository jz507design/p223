"""Historial de auditorias en SQLite.

Guarda cada escaneo con su resumen y la ruta del reporte generado.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from auditor_ia.scanner.pii import PiiFinding
from auditor_ia.scanner.permisos import PermissionFinding
from auditor_ia.scanner.procesos import ProcessInfo
from auditor_ia.scanner.puertos import PortInfo
from auditor_ia.scanner.runner import AuditResult
from auditor_ia.scanner.secretos import SecretFinding

_SCHEMA = """
CREATE TABLE IF NOT EXISTS auditorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    risk_level TEXT,
    summary TEXT,
    recommendations TEXT,
    report_path TEXT,
    raw_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_auditorias_timestamp ON auditorias(timestamp);
CREATE TABLE IF NOT EXISTS alertas_trafico (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    host TEXT NOT NULL,
    path TEXT,
    method TEXT,
    risk TEXT,
    reason TEXT,
    details TEXT
);
CREATE INDEX IF NOT EXISTS idx_alertas_timestamp ON alertas_trafico(timestamp);
"""

# Columnas que pueden faltar en DBs creadas por versiones previas.
_LATE_COLUMNS = {
    "recommendations": "TEXT",
}


def ensure_schema(db_path: Path) -> None:
    """Aplica el esquema y migra columnas agregadas en versiones nuevas.

    Publica para que el panel y el CLI puedan migrar una DB creada por
    una version anterior sin romper consultas.
    """
    with sqlite3.connect(db_path) as conn:
        conn.executescript(_SCHEMA)
        existing = {row[1] for row in conn.execute("PRAGMA table_info(auditorias)")}
        for col, col_type in _LATE_COLUMNS.items():
            if col not in existing:
                conn.execute(f"ALTER TABLE auditorias ADD COLUMN {col} {col_type}")


def _ensure_schema(db_path: Path) -> None:
    """Compatibilidad interna: delega en la migracion publica."""
    ensure_schema(db_path)


def _to_json(result: AuditResult) -> str:
    return json.dumps(
        {
            "timestamp": result.timestamp,
            "processes": [
                {"pid": p.pid, "name": p.name, "cmdline": list(p.cmdline), "ia": p.is_ia_related}
                for p in result.processes
            ],
            "ports": [
                {"port": p.port, "service": p.service, "state": p.state}
                for p in result.ports
            ],
            "secrets": [
                {"location": s.location, "name": s.name, "masked": s.masked_value, "risk": s.risk}
                for s in result.secrets
            ],
            "permissions": [
                {"path": p.path, "exists": p.exists, "risk": p.risk}
                for p in result.permissions
            ],
            "pii": [
                {"entity": f.entity, "score": f.score, "value": f.value}
                for f in result.pii_findings
            ],
        },
        ensure_ascii=False,
    )


def save_audit(
    db_path: Path,
    result: AuditResult,
    risk_level: str = "",
    summary: str = "",
    recommendations: list[str] | None = None,
    report_path: str = "",
) -> int:
    _ensure_schema(db_path)
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute(
            "INSERT INTO auditorias (timestamp, risk_level, summary, recommendations, report_path, raw_json) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                result.timestamp,
                risk_level,
                summary,
                json.dumps(recommendations or [], ensure_ascii=False),
                report_path,
                _to_json(result),
            ),
        )
        return int(cur.lastrowid)


def result_from_json(data: str) -> AuditResult:
    """Reconstruye un AuditResult desde el JSON guardado en SQLite."""
    obj = json.loads(data)
    return AuditResult(
        timestamp=obj.get("timestamp", ""),
        processes=[
            ProcessInfo(
                pid=p["pid"],
                name=p["name"],
                cmdline=tuple(p.get("cmdline", [])),
                is_ia_related=p.get("ia", False),
                exe=p.get("exe", ""),
            )
            for p in obj.get("processes", [])
        ],
        ports=[
            PortInfo(port=p["port"], service=p["service"], state=p["state"])
            for p in obj.get("ports", [])
        ],
        secrets=[
            SecretFinding(
                location=s["location"],
                name=s["name"],
                masked_value=s["masked"],
                risk=s["risk"],
            )
            for s in obj.get("secrets", [])
        ],
        permissions=[
            PermissionFinding(path=p["path"], exists=p["exists"], risk=p["risk"])
            for p in obj.get("permissions", [])
        ],
        pii_findings=[
            PiiFinding(
                entity=f["entity"],
                start=f.get("start", 0),
                end=f.get("end", 0),
                score=f.get("score", 0.0),
                value=f.get("value", ""),
            )
            for f in obj.get("pii", [])
        ],
    )


def update_verdict(
    db_path: Path,
    audit_id: int,
    risk_level: str,
    summary: str,
    recommendations: list[str],
) -> bool:
    """Guarda el veredicto de la IA sobre una auditoria ya existente."""
    _ensure_schema(db_path)
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute(
            "UPDATE auditorias SET risk_level = ?, summary = ?, recommendations = ? "
            "WHERE id = ?",
            (risk_level, summary, json.dumps(recommendations, ensure_ascii=False), audit_id),
        )
        return cur.rowcount > 0


def save_report_path(db_path: Path, audit_id: int, report_path: str) -> None:
    """Actualiza la ruta del reporte generado de una auditoria."""
    _ensure_schema(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            "UPDATE auditorias SET report_path = ? WHERE id = ?",
            (report_path, audit_id),
        )


def get_audit(db_path: Path, audit_id: int) -> dict | None:
    """Devuelve una auditoria completa con su resultado reconstruido."""
    _ensure_schema(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT id, timestamp, risk_level, summary, recommendations, report_path, raw_json "
            "FROM auditorias WHERE id = ?",
            (audit_id,),
        ).fetchone()
    if row is None:
        return None
    item = dict(row)
    item["result"] = result_from_json(row["raw_json"])
    try:
        item["recommendations"] = json.loads(item.get("recommendations") or "[]")
    except (TypeError, json.JSONDecodeError):
        item["recommendations"] = []
    return item


def load_history(db_path: Path, limit: int = 20) -> list[dict]:
    """Devuelve el historial reciente, mas reciente primero."""
    _ensure_schema(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT id, timestamp, risk_level, summary, recommendations, report_path "
            "FROM auditorias ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    items = [dict(row) for row in rows]
    for item in items:
        try:
            item["recommendations"] = json.loads(item.get("recommendations") or "[]")
        except (TypeError, json.JSONDecodeError):
            item["recommendations"] = []
    return items


# ---------------------------------------------------------------------------
# Alertas de trafico (interceptor)
# ---------------------------------------------------------------------------

def save_alert(db_path: Path, alert: "TrafficAlert") -> int:
    """Guarda una alerta de trafico saliente en SQLite."""
    _ensure_schema(db_path)
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute(
            "INSERT INTO alertas_trafico (timestamp, host, path, method, risk, reason, details) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (alert.timestamp, alert.host, alert.path, alert.method, alert.risk,
             alert.reason, alert.details),
        )
        return int(cur.lastrowid)


def load_alerts(db_path: Path, limit: int = 50) -> list[dict]:
    """Devuelve las alertas de trafico recientes, mas recientes primero."""
    _ensure_schema(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT id, timestamp, host, path, method, risk, reason, details "
            "FROM alertas_trafico ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]
