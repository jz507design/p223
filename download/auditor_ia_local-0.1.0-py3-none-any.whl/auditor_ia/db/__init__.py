"""Persistencia del historial de auditorias (SQLite)."""
