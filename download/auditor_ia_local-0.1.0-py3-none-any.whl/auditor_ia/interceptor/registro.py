"""Deteccion de trafico saliente: registro de alertas a disco."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from auditor_ia.interceptor.interceptor import TrafficAlert


def save_alerts(alerts: list[TrafficAlert], output_dir: Path) -> Path:
    """Guarda las alertas en un JSON con timestamp para trazabilidad."""
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / f"alertas_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
    payload = [vars(a) for a in alerts]
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target
