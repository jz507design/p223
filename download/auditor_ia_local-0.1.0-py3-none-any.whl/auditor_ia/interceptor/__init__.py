"""Interceptor de trafico saliente (mitmproxy)."""
