"""Interceptor de trafico saliente con mitmproxy.

Captura peticiones HTTP/HTTPS hacia APIs externas, las analiza en busca
de PII/secretos y registra alertas. Todo el analisis es local.

Uso como addon de mitmproxy:
    mitmproxy -s interceptor.py --listen-port 8080

Tambien se puede integrar en codigo con InterceptorHooks (ver abajo).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from auditor_ia.scanner.pii import PiiDetector

# Dominios de APIs de IA externas (se monitorean con prioridad)
EXTERNAL_AI_DOMAINS: tuple[str, ...] = (
    "api.openai.com",
    "api.anthropic.com",
    "generativelanguage.googleapis.com",
    "api.deepseek.com",
    "api.mistral.ai",
    "api.cohere.ai",
    "api.groq.com",
    "api.together.xyz",
    "api.replicate.com",
    "huggingface.co",
)

# Dominios internos que siempre se ignoran
_BYPASS_SUBSTRINGS: tuple[str, ...] = (
    "127.0.0.1",
    "localhost",
    ".local",
    "10.",
    "192.168.",
    "172.16.",
    "172.31.",
)

# Patrones de rutas que suelen contener datos (prompts, mensajes)
_DATA_PATHS: re.Pattern[str] = re.compile(
    r"/(chat/completions|completions|generate|messages|embeddings|"
    r"responses|inference|api/chat)(\?|$)",
    re.I,
)


@dataclass(slots=True)
class TrafficAlert:
    timestamp: str
    host: str
    path: str
    method: str
    risk: str  # alto | medio
    reason: str
    details: str = ""


class InterceptorHooks:
    """Hooks de mitmproxy: respuesta(request) y respuesta(response).

    La clase recibe los eventos de mitmproxy y delega el analisis al
    PiiDetector, acumulando alertas en memoria y (opcional) guardandolas
    en SQLite al instante para trazabilidad en tiempo real.
    """

    def __init__(self, db_path: Path | None = None) -> None:
        self._pii = PiiDetector()
        self.alerts: list[TrafficAlert] = []
        self._db_path = db_path

    # -- helpers -------------------------------------------------------

    def _relevant(self, host: str) -> bool:
        """Es un host externo de IA que queremos inspeccionar?"""
        if any(b in host for b in _BYPASS_SUBSTRINGS):
            return False
        return any(host.endswith(d) or d in host for d in EXTERNAL_AI_DOMAINS)

    def _check_body(self, host: str, path: str, method: str, body: str) -> None:
        """Analiza el cuerpo de la peticion en busca de PII y secretos."""
        if not body or not self._relevant(host):
            return
        analysis = self._pii.anonymize(body)
        if analysis.count:
            entities = ", ".join(sorted({f.entity for f in analysis.findings}))
            alert = TrafficAlert(
                timestamp=datetime.now(timezone.utc).isoformat(),
                host=host,
                path=path,
                method=method,
                risk="alto",
                reason=f"PII en trafico saliente ({entities})",
                details=analysis.anonymized[:500],
            )
            self.alerts.append(alert)
            if self._db_path is not None:
                from auditor_ia.db.historial import ensure_schema, save_alert

                ensure_schema(self._db_path)
                save_alert(self._db_path, alert)

    # -- eventos mitmproxy ---------------------------------------------

    def request(self, flow) -> None:
        """Se ejecuta al capturar una peticion saliente."""
        try:
            host = flow.request.pretty_host
            path = flow.request.path
            method = flow.request.method
            if not _DATA_PATHS.search(path):
                return
            body = flow.request.get_text() or ""
            self._check_body(host, path, method, body)
        except Exception:
            # Nunca derribar el proxy por un error de analisis
            pass

    def response(self, flow) -> None:
        """Opcional: tambien puede inspeccionar respuestas si se necesita."""
        pass
