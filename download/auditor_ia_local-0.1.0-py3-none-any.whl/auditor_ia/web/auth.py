"""Autenticacion simple del panel web.

Protege el panel con una contrasena configurable (AUDITOR_PANEL_PASSWORD
o config/settings.toml). Si no se configura, el panel queda abierto (modo
desarrollo). La sesion es una cookie firmada con HMAC-SHA256; sin
dependencias nuevas, sin bases de usuarios.

Flujo:
    1. POST /login  -> valida contrasena y emite cookie firmada
    2. Cookie       -> verificada en cada request protegido
    3. POST /logout -> borra la cookie
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request, Response
from starlette.responses import RedirectResponse

COOKIE_NAME = "auditor_session"
_SESSION_TTL = timedelta(hours=12)


def _sign(payload: str, secret: str) -> str:
    """Firma un payload con HMAC-SHA256 y devuelve base64 URL-safe."""
    digest = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(digest).decode()


def make_session_token(secret: str) -> str:
    """Crea un token de sesion firmado con expiracion embebida."""
    expires = datetime.now(timezone.utc) + _SESSION_TTL
    payload = f"{int(expires.timestamp())}"
    return f"{payload}.{_sign(payload, secret)}"


def verify_session_token(token: str, secret: str) -> bool:
    """Valida la firma y la expiracion del token de sesion."""
    try:
        payload, signature = token.split(".", 1)
    except ValueError:
        return False
    expected = _sign(payload, secret)
    if not hmac.compare_digest(signature, expected):
        return False
    try:
        expires = datetime.fromtimestamp(int(payload), tz=timezone.utc)
    except (ValueError, OSError):
        return False
    return expires > datetime.now(timezone.utc)


def login_required(request: Request):
    """Dependency de FastAPI: redirige a /login si no hay sesion valida.

    En FastAPI una dependency no puede 'devolver' la respuesta final de la
    ruta: debe lanzar HTTPException para cortar la request. Con status 303
    y header Location el navegador hace el redirect como en una ruta.
    """
    secret = getattr(request.app.state, "panel_secret", "")
    if not secret:
        return None

    token = request.cookies.get(COOKIE_NAME, "")
    if token and verify_session_token(token, secret):
        return None

    raise HTTPException(status_code=303, headers={"Location": "/login"})


def set_session_cookie(response: Response, secret: str) -> None:
    """Pone la cookie de sesion firmada en la respuesta."""
    response.set_cookie(
        COOKIE_NAME,
        make_session_token(secret),
        max_age=int(_SESSION_TTL.total_seconds()),
        httponly=True,
        samesite="lax",
    )


def clear_session_cookie(response: Response) -> None:
    """Borra la cookie de sesion."""
    response.delete_cookie(COOKIE_NAME)


def random_secret() -> str:
    """Genera un secreto aleatorio si el admin no configuro uno."""
    return secrets.token_urlsafe(32)
