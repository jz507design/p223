"""Panel web de P223 — Policía de IAs (FastAPI + Jinja2)."""
