"""Aplicacion FastAPI del panel web.

Rutas:
    GET  /                            dashboard con estadisticas y ultima auditoria
    GET  /historial                   historial completo
    GET  /auditoria/{id}              detalle de una auditoria
    POST /escanear                    ejecuta un escaneo de entorno y lo guarda
    GET  /auditoria/{id}/exportar     JSON limpio de la auditoria (para la IA empresa)
    POST /auditoria/{id}/veredicto    ejecuta el modelo local y guarda el veredicto IA
    POST /auditoria/{id}/reporte      genera el reporte HTML/PDF desde el panel
    GET  /auditoria/{id}/descargar    descarga el reporte generado (para el cliente)
    GET  /login | POST /login | POST /logout
                                      autenticacion del panel (si hay contrasena)

Arranque:  python -m auditor_ia.web.app   (o:  p223 web)
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import sqlite3
from pathlib import Path

from fastapi import Depends, FastAPI, Form, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from auditor_ia.config import REPORTS_DIR, Settings
from auditor_ia.db.historial import (
    _to_json,
    ensure_schema,
    get_audit,
    result_from_json,
    save_audit,
    save_report_path,
    update_verdict,
)
from auditor_ia.report.generador import save_report
from auditor_ia.scanner.runner import run_scan, summarize_result
from auditor_ia.semantic.motor import OllamaUnavailableError, audit_with_ollama
from auditor_ia.web.auth import (
    clear_session_cookie,
    login_required,
    random_secret,
    set_session_cookie,
)

app = FastAPI(title="P223 — Policía de IAs", version="0.1.0")

TEMPLATES_DIR = Path(__file__).parent / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


def _get_settings() -> Settings:
    return Settings.from_env()


def _setup_auth() -> None:
    """Configura password/secret del panel.

    Se ejecuta al importar el modulo (no en un evento startup) para que
    funcione igual bajo uvicorn, TestClient o el modo debug.

    Regla clave: si no hay contrasena, tampoco hay secret. Asi el
    login_required ve secret vacio y deja pasar (modo desarrollo). Si
    hubiera secret sin contrasena, / redirigiria a /login y /login
    volveria a / -> bucle de redirects.
    """
    settings = _get_settings()
    app.state.panel_password = settings.panel_password
    app.state.panel_secret = settings.panel_secret or (random_secret() if settings.panel_password else "")


_setup_auth()


def _rows(db_path: Path, limit: int = 50) -> list[dict]:
    """Lee filas del historial con su resultado reconstruido."""
    ensure_schema(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT id, timestamp, risk_level, summary, recommendations, report_path, raw_json "
            "FROM auditorias ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()

    items = []
    for row in rows:
        item = dict(row)
        try:
            item["recommendations"] = json.loads(item.get("recommendations") or "[]")
        except (TypeError, json.JSONDecodeError):
            item["recommendations"] = []
        item["result"] = result_from_json(row["raw_json"])
        items.append(item)
    return items


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request, error: str = ""):
    if not app.state.panel_password:
        return RedirectResponse(url="/", status_code=303)
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={"error": error},
    )


@app.post("/login")
def login(request: Request, password: str = Form("")):
    # Form() lee el campo 'password' del form-urlencoded del template.
    configured = app.state.panel_password
    if not configured:
        return RedirectResponse(url="/", status_code=303)
    if not password or not hmac.compare_digest(password.encode(), configured.encode()):
        return login_page(request, error="Contraseña incorrecta")
    resp = RedirectResponse(url="/", status_code=303)
    set_session_cookie(resp, app.state.panel_secret)
    return resp


@app.post("/logout")
def logout():
    resp = RedirectResponse(url="/login", status_code=303)
    clear_session_cookie(resp)
    return resp


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, _: None = Depends(login_required)):
    settings = _get_settings()
    filas = _rows(settings.db_path)

    ultimo = filas[0] if filas else None
    total = len(filas)
    procesos_ia = sum(len(f["result"].ia_processes) for f in filas)
    puertos = sum(len(f["result"].open_ports) for f in filas)
    secretos = sum(len(f["result"].secrets) + len(f["result"].pii_findings) for f in filas)

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "filas": filas,
            "ultimo": ultimo,
            "total_auditorias": total,
            "procesos_ia": procesos_ia,
            "puertos_abiertos": puertos,
            "secretos": secretos,
            "protegido": bool(app.state.panel_password),
        },
    )


@app.get("/historial", response_class=HTMLResponse)
def historial(request: Request, _: None = Depends(login_required)):
    settings = _get_settings()
    filas = _rows(settings.db_path, limit=200)
    return templates.TemplateResponse(
        request=request,
        name="historial.html",
        context={"filas": filas, "protegido": bool(app.state.panel_password)},
    )


@app.get("/auditoria/{audit_id}", response_class=HTMLResponse)
def detalle(request: Request, audit_id: int, _: None = Depends(login_required)):
    settings = _get_settings()
    fila = get_audit(settings.db_path, audit_id)

    if fila is None:
        return HTMLResponse("<h1>404 — Auditoría no encontrada</h1>", status_code=404)

    return templates.TemplateResponse(
        request=request,
        name="detalle.html",
        context={"fila": fila, "result": fila["result"], "protegido": bool(app.state.panel_password)},
    )


@app.post("/escanear")
def escanear(_: None = Depends(login_required)):
    settings = _get_settings()
    result = run_scan(settings)
    new_id = save_audit(settings.db_path, result)
    return RedirectResponse(url=f"/auditoria/{new_id}", status_code=303)


@app.get("/auditoria/{audit_id}/exportar")
def exportar(audit_id: int, _: None = Depends(login_required)):
    """Devuelve la auditoria como JSON limpio (sin HTML).

    Este es el formato pensado para alimentar la IA de la empresa y/o
    integrarse con el flujo de reportes del panel central.
    """
    settings = _get_settings()
    fila = get_audit(settings.db_path, audit_id)
    if fila is None:
        return HTMLResponse("<h1>404 — Auditoría no encontrada</h1>", status_code=404)

    payload = {
        "id": fila["id"],
        "timestamp": fila["timestamp"],
        "risk_level": fila["risk_level"] or "",
        "summary": fila["summary"] or "",
        "recommendations": fila["recommendations"],
        "report_path": fila["report_path"] or "",
        "result": json.loads(_to_json(fila["result"])),
    }
    from fastapi.responses import JSONResponse

    return JSONResponse(payload)


@app.post("/auditoria/{audit_id}/veredicto")
def veredicto_ia(audit_id: int, _: None = Depends(login_required)):
    """Ejecuta el modelo local sobre una auditoria guardada y guarda el veredicto."""
    settings = _get_settings()
    fila = get_audit(settings.db_path, audit_id)
    if fila is None:
        return HTMLResponse("<h1>404 — Auditoría no encontrada</h1>", status_code=404)

    try:
        verdict = audit_with_ollama(settings, summarize_result(fila["result"]))
    except OllamaUnavailableError:
        return RedirectResponse(
            url=f"/auditoria/{audit_id}?error=ollama", status_code=303
        )

    update_verdict(
        settings.db_path,
        audit_id,
        verdict.risk_level,
        verdict.summary,
        verdict.recommendations,
    )
    return RedirectResponse(url=f"/auditoria/{audit_id}?veredicto=ok", status_code=303)


@app.post("/auditoria/{audit_id}/reporte")
def generar_reporte(audit_id: int, _: None = Depends(login_required)):
    """Genera el reporte HTML/PDF desde el panel y guarda su ruta."""
    from auditor_ia.semantic.motor import AuditVerdict

    settings = _get_settings()
    fila = get_audit(settings.db_path, audit_id)
    if fila is None:
        return HTMLResponse("<h1>404 — Auditoría no encontrada</h1>", status_code=404)

    verdict = None
    if fila["summary"] or fila["risk_level"]:
        verdict = AuditVerdict(
            summary=fila["summary"],
            risk_level=fila["risk_level"] or "medio",
            recommendations=fila["recommendations"],
        )

    report_path = save_report(
        fila["result"],
        REPORTS_DIR,
        verdict=verdict,
        as_pdf=(settings.report_format == "pdf"),
        modelo=settings.auditor_model,
    )
    save_report_path(settings.db_path, audit_id, str(report_path))
    return RedirectResponse(url=f"/auditoria/{audit_id}?reporte=ok", status_code=303)


@app.get("/auditoria/{audit_id}/descargar")
def descargar_reporte(audit_id: int, _: None = Depends(login_required)):
    """Descarga el reporte generado (PDF/HTML) para enviarlo al cliente."""
    settings = _get_settings()
    fila = get_audit(settings.db_path, audit_id)
    if fila is None:
        return HTMLResponse("<h1>404 — Auditoría no encontrada</h1>", status_code=404)

    ruta = Path(fila["report_path"]) if fila.get("report_path") else None
    if ruta is None or not ruta.exists():
        return HTMLResponse("<h1>404 — Reporte no generado</h1>", status_code=404)

    return FileResponse(path=ruta, filename=ruta.name)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
