"""CLI de P223 — Policia de IAs (Auditor de IA Local, es/en).

Uso:
    p223                              # elige idioma y arranca el menú interactivo
    p223 --lang en scan               # escaneo rápido sin modelo (en inglés)
    p223 --lang es audit              # escaneo + veredicto del modelo local (Ollama)
    p223 pii --text "..."             # detecta y anonimiza PII en un texto
    p223 pii --file ruta              # detecta y anonimiza PII en un archivo
    p223 proxy --port 8080            # arranca el interceptor de tráfico (mitmproxy)
    p223 monitor --port 8080          # interceptor con registro en SQLite
    p223 web --port 8000              # arranca el panel web (FastAPI)
    p223 history                      # historial de auditorías
    p223 tui                          # menú interactivo en terminal (rich)
    p223 demo                         # demo de venta: escaneo + IA + reporte
"""

from __future__ import annotations

import argparse
import sys

from auditor_ia.config import REPORTS_DIR, Settings
from auditor_ia.db.historial import load_history, save_audit
from auditor_ia.i18n import LANGS, elegir_idioma, tr
from auditor_ia.report.generador import save_report
from auditor_ia.scanner.pii import PiiDetector
from auditor_ia.scanner.runner import run_scan, summarize_result
from auditor_ia.semantic.motor import OllamaUnavailableError, audit_with_ollama


def _force_utf8() -> None:
    """Reconfigura la salida a UTF-8.

    Windows usa cp1252 por defecto y los veredictos del modelo local
    (y los nombres en espanol) contienen caracteres fuera de ese rango.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def _formato_reportes(settings: Settings, forzar_pdf: bool = False) -> str:
    """Resuelve el formato de reporte: flag --pdf > env > default html."""
    if forzar_pdf:
        return "pdf"
    return settings.report_format


def cmd_scan(args: argparse.Namespace) -> int:
    lang = args.lang
    settings = Settings.from_env()
    result = run_scan(settings)

    print(f"{tr(lang, 'scan_titulo')}: {result.timestamp}")
    print(summarize_result(result, lang=lang))

    for proc in result.ia_processes:
        print(f"  {tr(lang, 'scan_ia')}: PID {proc.pid} — {proc.name} ({' '.join(proc.cmdline)[:80]})")
    for port in result.open_ports:
        print(f"  {tr(lang, 'scan_puerto')} {port.port}: {port.service} [{tr(lang, 'scan_abierto')}]")
    for secret in result.secrets:
        print(f"  {tr(lang, 'scan_secreto')} [{secret.risk}]: {secret.location} {secret.name} = {secret.masked_value}")
    for perm in result.permissions:
        if perm.risk != "bajo":
            print(f"  {tr(lang, 'scan_permiso')} [{perm.risk}]: {perm.path}")

    if args.verbose:
        print(f"{tr(lang, 'scan_total_procesos')}: {len(result.processes)}")

    report_path = save_report(result, REPORTS_DIR,
                               as_pdf=(_formato_reportes(settings, bool(getattr(args, "pdf", False))) == "pdf"),
                               modelo=settings.auditor_model)
    save_audit(settings.db_path, result, report_path=str(report_path))
    print(f"{tr(lang, 'reporte')}: {report_path}")
    return 0


def cmd_audit(args: argparse.Namespace) -> int:
    lang = args.lang
    settings = Settings.from_env()
    result = run_scan(settings)
    summary = summarize_result(result, lang=lang)

    print(tr(lang, "audit_corriendo"))
    try:
        verdict = audit_with_ollama(settings, summary)
    except OllamaUnavailableError as exc:
        print(f"{tr(lang, 'audit_error_ollama')}: {exc}", file=sys.stderr)
        print(tr(lang, "audit_sin_veredicto"))
        verdict = None

    print(f"{tr(lang, 'audit_riesgo')}: {verdict.risk_level if verdict else tr(lang, 'audit_nd')}")
    if verdict:
        print(f"{tr(lang, 'audit_resumen')}: {verdict.summary}")
        for rec in verdict.recommendations:
            print(f"  - {rec}")

    report_path = save_report(result, REPORTS_DIR, verdict=verdict,
                              as_pdf=(_formato_reportes(settings, bool(getattr(args, "pdf", False))) == "pdf"),
                              modelo=settings.auditor_model)
    save_audit(
        settings.db_path,
        result,
        risk_level=verdict.risk_level if verdict else "",
        summary=verdict.summary if verdict else "",
        recommendations=verdict.recommendations if verdict else None,
        report_path=str(report_path),
    )
    print(f"{tr(lang, 'reporte')}: {report_path}")
    return 0


def cmd_pii(args: argparse.Namespace) -> int:
    """Analiza y anonimiza PII en un texto o archivo."""
    lang = args.lang
    detector = PiiDetector()
    if args.file:
        try:
            text = open(args.file, encoding="utf-8", errors="ignore").read()
        except OSError as exc:
            print(tr(lang, "pii_error_leer", path=args.file, error=exc), file=sys.stderr)
            return 1
        label = args.file
    elif args.text:
        text = args.text
        label = "texto" if lang == "es" else "text"
    else:
        print(tr(lang, "pii_error_args"), file=sys.stderr)
        return 1

    analysis = detector.anonymize(text)
    print(f"{tr(lang, 'pii_detectadas')} {label}: {analysis.count}")
    for f in sorted(analysis.findings, key=lambda x: x.start):
        print(f"  [{f.entity:15s}] score={f.score:.2f}  valor={f.value!r}")

    if args.show_anonymized:
        print(f"\n{tr(lang, 'pii_anonimizado')}:")
        print(analysis.anonymized)
    return 0


def cmd_proxy(args: argparse.Namespace) -> int:
    """Arranca el interceptor de trafico con mitmproxy."""
    import asyncio

    import mitmproxy.options
    from mitmproxy.tools.dump import DumpMaster

    from auditor_ia.interceptor.interceptor import InterceptorHooks
    from auditor_ia.interceptor.registro import save_alerts

    lang = args.lang

    async def run_proxy() -> int:
        opts = mitmproxy.options.Options(listen_host="127.0.0.1", listen_port=args.port)
        master = DumpMaster(opts)
        hooks = InterceptorHooks(db_path=args.db_path)
        master.addons.add(hooks)
        print(tr(lang, "proxy_inicio", port=args.port))
        print(tr(lang, "proxy_ayuda"))
        try:
            await master.run()
        except KeyboardInterrupt:
            pass
        finally:
            master.shutdown()
            if hooks.alerts:
                target = save_alerts(hooks.alerts, REPORTS_DIR / "alertas")
                print(f"\n{tr(lang, 'proxy_alertas')}: {len(hooks.alerts)}")
                for alert in hooks.alerts:
                    print(f"  [{alert.risk}] {alert.host} {alert.method} {alert.path} — {alert.reason}")
                print(f"{tr(lang, 'proxy_guardadas')}: {target}")
            else:
                print(f"\n{tr(lang, 'proxy_sin_alertas')}")
        return 0

    return asyncio.run(run_proxy())


def cmd_monitor(args: argparse.Namespace) -> int:
    """Interceptor en modo monitor: guarda alertas en SQLite y muestra en vivo.

    Diferencia con 'proxy': no se limita a la sesion; cada alerta queda
    registrada en la DB con timestamp para el historial del cliente.
    """
    from auditor_ia.config import Settings
    from auditor_ia.db.historial import load_alerts
    from auditor_ia.interceptor.interceptor import InterceptorHooks

    import asyncio

    import mitmproxy.options
    from mitmproxy.tools.dump import DumpMaster

    settings = Settings.from_env()
    lang = args.lang

    async def run_monitor() -> int:
        opts = mitmproxy.options.Options(listen_host="127.0.0.1", listen_port=args.port)
        master = DumpMaster(opts)
        hooks = InterceptorHooks(db_path=settings.db_path)
        master.addons.add(hooks)
        print(tr(lang, "monitor_inicio", port=args.port))
        print(tr(lang, "monitor_db"))
        print(tr(lang, "monitor_ctrl_c"))
        try:
            await master.run()
        except KeyboardInterrupt:
            pass
        finally:
            master.shutdown()
            total = len(load_alerts(settings.db_path))
            print(f"\n{tr(lang, 'monitor_sesion')}: {len(hooks.alerts)}")
            print(f"{tr(lang, 'monitor_total')}: {total}")
        return 0

    return asyncio.run(run_monitor())


def cmd_demo(args: argparse.Namespace) -> int:
    """Demo de venta: escaneo + veredicto + reporte en un solo paso.

    Pensado para presentar el producto en la maquina de un prospecto:
    corre todo el flujo (escaneo, IA local, reporte) y abre el panel.
    """
    from auditor_ia.config import Settings
    from auditor_ia.db.historial import load_history, save_audit
    from auditor_ia.report.generador import save_report
    from auditor_ia.semantic.motor import OllamaUnavailableError, audit_with_ollama

    import webbrowser

    settings = Settings.from_env()
    lang = args.lang

    print(tr(lang, "demo_titulo"))
    print(tr(lang, "demo_1"))
    result = run_scan(settings)
    summary = summarize_result(result, lang=lang)
    print(f"  {summary}")

    print(tr(lang, "demo_2"))
    try:
        verdict = audit_with_ollama(settings, summary)
    except OllamaUnavailableError as exc:
        print(f"  {tr(lang, 'demo_aviso')}: {exc}")
        verdict = None

    if verdict:
        print(f"  {tr(lang, 'demo_riesgo')}: {verdict.risk_level.upper()}")
        print(f"  {verdict.summary}")
        for rec in verdict.recommendations:
            print(f"    - {rec}")

    print(tr(lang, "demo_3"))
    report_path = save_report(
        result,
        REPORTS_DIR,
        verdict=verdict,
        as_pdf=(_formato_reportes(settings, bool(getattr(args, "pdf", False))) == "pdf"),
        modelo=settings.auditor_model,
    )
    audit_id = save_audit(
        settings.db_path,
        result,
        risk_level=verdict.risk_level if verdict else "",
        summary=verdict.summary if verdict else "",
        recommendations=verdict.recommendations if verdict else None,
        report_path=str(report_path),
    )
    print(f"  {tr(lang, 'reporte')}: {report_path}")
    print(f"  {tr(lang, 'demo_guardada')}: #{audit_id}")

    if args.web:
        print(tr(lang, "demo_4"))
        webbrowser.open("http://127.0.0.1:8000")
        return cmd_web(args)

    rows = load_history(settings.db_path, limit=3)
    print(f"\n{tr(lang, 'demo_ultimas')}:")
    for row in rows:
        print(f"  #{row['id']} {row['timestamp'][:19]} — {row['risk_level'] or tr(lang, 'audit_nd')}")
    print(f"\n{tr(lang, 'demo_fin')}")
    return 0


def cmd_web(args: argparse.Namespace) -> int:
    """Arranca el panel web (FastAPI + Uvicorn)."""
    import uvicorn

    from auditor_ia.web.app import app

    print(tr(args.lang, "web_inicio", port=args.port))
    uvicorn.run(app, host=args.host, port=args.port)
    return 0


def cmd_tui(args: argparse.Namespace) -> int:
    """Arranca la interfaz interactiva de terminal (rich)."""
    from auditor_ia.tui import main as tui_main

    return tui_main(lang=args.lang)


def cmd_history(args: argparse.Namespace) -> int:
    lang = args.lang
    settings = Settings.from_env()
    rows = load_history(settings.db_path, limit=args.limit)
    if not rows:
        print(tr(lang, "hist_vacio"))
        return 0
    for row in rows:
        print(
            f"[{row['id']}] {row['timestamp']} — "
            f"{tr(lang, 'hist_riesgo')} {row['risk_level'] or tr(lang, 'audit_nd')} — {row['report_path'] or ''}"
        )
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="p223", description=tr("es", "descripcion"))
    parser.add_argument(
        "--lang",
        choices=LANGS,
        default="es",
        help=tr("es", "lang_help"),
    )
    sub = parser.add_subparsers(dest="command")

    p_scan = sub.add_parser("scan", help=tr("es", "cmd_scan"))
    p_scan.add_argument("-v", "--verbose", action="store_true", help=tr("es", "arg_verbose"))
    p_scan.add_argument("--pdf", action="store_true", help=tr("es", "arg_pdf"))
    p_scan.set_defaults(func=cmd_scan)

    p_audit = sub.add_parser("audit", help=tr("es", "cmd_audit"))
    p_audit.add_argument("--pdf", action="store_true", help=tr("es", "arg_pdf"))
    p_audit.set_defaults(func=cmd_audit)

    p_pii = sub.add_parser("pii", help=tr("es", "cmd_pii"))
    p_pii.add_argument("--text", help=tr("es", "arg_text"))
    p_pii.add_argument("--file", help=tr("es", "arg_file"))
    p_pii.add_argument("-s", "--show-anonymized", action="store_true",
                       help=tr("es", "arg_anonymized"))
    p_pii.set_defaults(func=cmd_pii)

    p_proxy = sub.add_parser("proxy", help=tr("es", "cmd_proxy"))
    p_proxy.add_argument("--port", type=int, default=8080, help=tr("es", "arg_port"))
    p_proxy.add_argument("--db-path", default=None, help=tr("es", "arg_db_path"))
    p_proxy.set_defaults(func=cmd_proxy)

    p_monitor = sub.add_parser("monitor", help=tr("es", "cmd_monitor"))
    p_monitor.add_argument("--port", type=int, default=8080, help=tr("es", "arg_port"))
    p_monitor.set_defaults(func=cmd_monitor)

    p_demo = sub.add_parser("demo", help=tr("es", "cmd_demo"))
    p_demo.add_argument("--web", action="store_true", help=tr("es", "arg_web"))
    p_demo.add_argument("--pdf", action="store_true", help=tr("es", "arg_pdf"))
    p_demo.set_defaults(func=cmd_demo)

    p_web = sub.add_parser("web", help=tr("es", "cmd_web"))
    p_web.add_argument("--host", default="127.0.0.1", help=tr("es", "arg_host"))
    p_web.add_argument("--port", type=int, default=8000, help=tr("es", "arg_port"))
    p_web.set_defaults(func=cmd_web)

    p_hist = sub.add_parser("history", help=tr("es", "cmd_history"))
    p_hist.add_argument("-n", "--limit", type=int, default=20, help=tr("es", "arg_limit"))
    p_hist.set_defaults(func=cmd_history)

    p_tui = sub.add_parser("tui", help=tr("es", "cmd_tui"))
    p_tui.set_defaults(func=cmd_tui)

    return parser


def main(argv: list[str] | None = None) -> int:
    _force_utf8()
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Sin comando: elige idioma y arranca la TUI (menú interactivo).
    if not getattr(args, "command", None):
        lang = elegir_idioma()
        args.lang = lang
        print(tr(lang, "sin_comando"))
        return cmd_tui(args)

    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
