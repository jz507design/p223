"""Generador de reportes premium en HTML y PDF (P223 — Policía de IAs).

Construye un informe de consultoria de seguridad: cabecera de marca,
KPI cards, graficos SVG (donut de riesgo + barras de procesos), tablas
detalladas y footer confidencial. El PDF se genera con Chromium via
Playwright desde el mismo HTML (una sola fuente de verdad).

Motivo de Playwright y no WeasyPrint: WeasyPrint arrastra pyphen (GPL),
que contamina un producto comercial. Playwright/Chromium son Apache-2.0
y BSD-3-Clause: uso comercial libre sin restricciones.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from jinja2 import Template

from auditor_ia.scanner.runner import AuditResult
from auditor_ia.semantic.motor import AuditVerdict

_TEMPLATE = Template(
    """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Informe de Auditoría — P223 · Policía de IAs</title>
<style>
  :root {
    --bg: #0c0e14;
    --panel: #141824;
    --panel2: #1a2030;
    --border: #242b3d;
    --text: #e8eaf0;
    --muted: #8b93a7;
    --gold: #d2bc93;
    --verde: #10b981;
    --amarillo: #f59e0b;
    --rojo: #ef4444;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  @page { size: A4; margin: 0; }
  body {
    font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
    background: var(--bg); color: var(--text); font-size: 10.5pt; line-height: 1.5;
  }
  .page { padding: 28pt 34pt 24pt; position: relative; }
  /* Evita que cards, tablas y veredictos se partan a mitad de pagina */
  .card, .veredicto, .kpi, table, .charts, h2, h3 { break-inside: avoid; }

  /* ---------- portada ---------- */
  /* La portada ocupa exactamente una pagina A4 y fuerza salto despues:
     asi el cover-meta (posicionado al pie) jamas se encima con la
     siguiente seccion. */
  .cover {
    height: 750pt; /* ~A4 menos padding */
    max-height: 750pt;
    position: relative;
    page-break-after: always;
  }
  .cover::after {
    content: ""; position: absolute; inset: 0; pointer-events: none;
    background: radial-gradient(900px 340px at 85% -10%, rgba(210,188,147,.12), transparent 60%),
                radial-gradient(700px 300px at -10% 110%, rgba(210,188,147,.06), transparent 60%);
  }
  .cover-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 40pt; }
  .brand { font-size: 13pt; font-weight: 800; letter-spacing: .06em; }
  .brand span { color: var(--gold); }
  .cover .ref { color: var(--muted); font-size: 8pt; text-align: right; }
  .cover h1 {
    font-size: 26pt; font-weight: 800; letter-spacing: -.01em; margin: 6pt 0 4pt;
  }
  .cover .sub { color: var(--muted); font-size: 10.5pt; max-width: 420pt; }
  .cover .selo { margin-top: 26pt; display: inline-block; }
  .selo-box {
    border: 1.5pt solid var(--gold); color: var(--gold); border-radius: 8pt;
    padding: 8pt 16pt; font-size: 9pt; font-weight: 700; letter-spacing: .18em;
  }
  .cover-meta {
    position: absolute; bottom: 0; left: 0; right: 0;
    border-top: 1pt solid var(--border); padding-top: 10pt; display: flex; gap: 28pt;
    color: var(--muted); font-size: 8.5pt;
  }
  .cover-meta b { color: var(--text); font-weight: 600; }

  /* ---------- estructura general ---------- */
  h2 {
    font-size: 13pt; font-weight: 800; margin: 22pt 0 10pt; color: var(--gold);
    letter-spacing: .02em; display: flex; align-items: center; gap: 8pt;
  }
  h2::before { content: ""; width: 4pt; height: 14pt; background: var(--gold); border-radius: 2pt; }
  h3 { font-size: 10.5pt; font-weight: 700; margin: 12pt 0 6pt; }
  .muted { color: var(--muted); }
  .small { font-size: 8pt; }

  /* ---------- KPI ---------- */
  .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10pt; }
  .kpi {
    background: linear-gradient(160deg, var(--panel), var(--panel2));
    border: 1pt solid var(--border); border-radius: 10pt; padding: 12pt 14pt;
  }
  .kpi .v { font-size: 19pt; font-weight: 800; line-height: 1.1; }
  .kpi .l { color: var(--muted); font-size: 7.5pt; text-transform: uppercase; letter-spacing: .08em; margin-top: 3pt; }
  .kpi .d { font-size: 8pt; margin-top: 4pt; }
  .kpi.verde .v { color: var(--verde); }
  .kpi.ambar .v { color: var(--amarillo); }
  .kpi.rojo .v { color: var(--rojo); }
  .kpi.gold .v { color: var(--gold); }

  /* ---------- veredicto ---------- */
  .veredicto {
    border-radius: 12pt; padding: 16pt 18pt; border: 1pt solid var(--border);
    background: linear-gradient(160deg, var(--panel), var(--panel2));
    display: flex; gap: 16pt; align-items: center;
  }
  .veredicto .badge-big {
    font-size: 14pt; font-weight: 800; border-radius: 10pt; padding: 10pt 16pt;
    color: #fff; letter-spacing: .05em; white-space: nowrap;
  }
  .badge-big.bajo { background: var(--verde); }
  .badge-big.medio { background: var(--amarillo); color: #111; }
  .badge-big.alto { background: var(--rojo); }
  .veredicto .txt { font-size: 10pt; color: var(--text); }

  /* ---------- tablas ---------- */
  table { width: 100%; border-collapse: collapse; margin: 6pt 0; }
  th, td { text-align: left; padding: 6pt 9pt; border-bottom: 1pt solid var(--border); font-size: 9pt; }
  th { color: var(--muted); font-weight: 700; text-transform: uppercase; font-size: 7.5pt; letter-spacing: .06em; }
  tr:hover { background: rgba(255,255,255,.02); }
  .badge { display: inline-block; padding: 2pt 8pt; border-radius: 99pt; font-weight: 700; font-size: 7.5pt; color: #fff; }
  .badge.bajo { background: var(--verde); }
  .badge.medio { background: var(--amarillo); color: #111; }
  .badge.alto { background: var(--rojo); }
  .badge.abierto { background: var(--rojo); }
  .badge.cerrado { background: var(--verde); }
  code { background: #1d2436; padding: 1pt 5pt; border-radius: 4pt; font-size: 8pt; }

  /* ---------- cards ---------- */
  .card {
    background: linear-gradient(160deg, var(--panel), var(--panel2));
    border: 1pt solid var(--border); border-radius: 10pt; padding: 12pt 14pt; margin: 6pt 0;
  }
  .reco { display: flex; gap: 10pt; align-items: flex-start; margin: 5pt 0; }
  .reco .n {
    min-width: 18pt; height: 18pt; border-radius: 50%; background: var(--gold); color: #111;
    font-weight: 800; font-size: 8.5pt; display: flex; align-items: center; justify-content: center;
  }
  .reco .t { font-size: 9.5pt; }

  /* ---------- graficos ---------- */
  .charts { display: grid; grid-template-columns: 1fr 1fr; gap: 12pt; margin-top: 6pt; }
  .chart-box { text-align: center; }
  .chart-box .cap { color: var(--muted); font-size: 8pt; margin-top: 4pt; }

  /* ---------- footer ---------- */
  .footer {
    margin-top: 22pt; padding-top: 10pt; border-top: 1pt solid var(--border);
    color: var(--muted); font-size: 7.5pt; display: flex; justify-content: space-between;
    gap: 20pt;
  }
  .footer b { color: var(--text); }
</style>
</head>
<body>
<div class="page">

  <!-- ================= PORTADA ================= -->
  <div class="cover">
    <div class="cover-top">
      <div class="brand">JZ Design Solutions <span>· P223</span></div>
      <div class="ref">Informe Confidencial<br>REF: {{ codigo }}</div>
    </div>
    <h1>Informe de Auditoría<br>de Entorno de IA Local</h1>
    <p class="sub">Evaluación de seguridad de sistemas de inteligencia artificial en la máquina.
       Procesos, puertos, secretos, permisos y análisis semántico con modelo local.
       Sin exfiltración de datos: todo se procesa en el equipo.</p>
    <div class="selo"><div class="selo-box">AUDITORÍA 100% LOCAL</div></div>
    <div class="cover-meta">
      <div><b>Fecha de escaneo</b><br>{{ fecha }}</div>
      <div><b>N° de procesos analizados</b><br>{{ result.processes|length }}</div>
      <div><b>Modelo auditor</b><br>{{ modelo }}</div>
      <div><b>Clasificación</b><br>Confidencial</div>
    </div>
  </div>

  <!-- ================= RESUMEN EJECUTIVO ================= -->
  <h2>Resumen ejecutivo</h2>
  <div class="kpi-grid">
    <div class="kpi {{ kpi_color(result.high_risk_count) }}">
      <div class="v">{{ result.high_risk_count }}</div>
      <div class="l">Hallazgos de alto riesgo</div>
      <div class="d">Secretos + permisos críticos</div>
    </div>
    <div class="kpi gold">
      <div class="v">{{ result.ia_processes|length }}</div>
      <div class="l">Procesos de IA local</div>
      <div class="d">En ejecución durante el escaneo</div>
    </div>
    <div class="kpi {{ 'ambar' if result.open_ports|length else 'verde' }}">
      <div class="v">{{ result.open_ports|length }}</div>
      <div class="l">Puertos abiertos</div>
      <div class="d">Servicios de IA expuestos</div>
    </div>
    <div class="kpi {{ 'rojo' if (result.secrets|length + result.pii_findings|length) else 'verde' }}">
      <div class="v">{{ result.secrets|length + result.pii_findings|length }}</div>
      <div class="l">Secretos / PII</div>
      <div class="d">Claves y datos personales</div>
    </div>
  </div>

  {% if verdict %}
  <div class="veredicto" style="margin-top:12pt;">
    <div class="badge-big {{ verdict.risk_level }}">RIESGO {{ verdict.risk_level|upper }}</div>
    <div class="txt">
      <strong>Veredicto del modelo auditor ({{ modelo }}):</strong><br>
      {{ verdict.summary }}
    </div>
  </div>
  {% endif %}

  <!-- ================= GRAFICOS ================= -->
  <h2>Análisis visual</h2>
  <div class="charts">
    <div class="chart-box">
      {{ donut(result) }}
      <div class="cap">Distribución de procesos de IA detectados</div>
    </div>
    <div class="chart-box">
      {{ barras(result) }}
      <div class="cap">Procesos de IA en ejecución (por PID)</div>
    </div>
  </div>

  <!-- ================= PROCESOS ================= -->
  <h2>Procesos de IA detectados</h2>
  {% if result.ia_processes %}
  <table>
    <tr><th>PID</th><th>Proceso</th><th>Línea de comando</th></tr>
    {% for p in result.ia_processes %}
    <tr><td>{{ p.pid }}</td><td><strong>{{ p.name }}</strong></td>
        <td class="muted small">{{ p.cmdline|join(' ')|truncate(110) }}</td></tr>
    {% endfor %}
  </table>
  {% else %}
  <div class="card muted">Ningún proceso de IA local en ejecución durante el escaneo.</div>
  {% endif %}

  <!-- ================= PUERTOS ================= -->
  <h2>Puertos y exposición</h2>
  <table>
    <tr><th>Puerto</th><th>Servicio</th><th>Estado</th></tr>
    {% for p in result.ports %}
    <tr>
      <td>{{ p.port }}</td>
      <td>{{ p.service }}</td>
      <td><span class="badge {{ 'abierto' if p.state == 'open' else 'cerrado' }}">{{ 'ABIERTO' if p.state == 'open' else 'Cerrado' }}</span></td>
    </tr>
    {% endfor %}
  </table>

  <!-- ================= SECRETOS ================= -->
  <h2>Secretos y claves expuestas</h2>
  {% if result.secrets %}
  <table>
    <tr><th>Origen</th><th>Variable</th><th>Valor (enmascarado)</th><th>Riesgo</th></tr>
    {% for s in result.secrets %}
    <tr>
      <td>{{ s.location }}</td><td><code>{{ s.name }}</code></td>
      <td><code>{{ s.masked_value }}</code></td>
      <td><span class="badge {{ s.risk }}">{{ s.risk|upper }}</span></td>
    </tr>
    {% endfor %}
  </table>
  {% else %}
  <div class="card muted">Sin secretos ni claves de API detectados en el entorno.</div>
  {% endif %}

  <!-- ================= PII ================= -->
  <h2>Información personal (PII)</h2>
  {% if result.pii_findings %}
  <table>
    <tr><th>Tipo</th><th>Confianza</th><th>Valor</th></tr>
    {% for p in result.pii_findings %}
    <tr><td>{{ p.entity }}</td><td>{{ '%.0f'|format(p.score * 100) }}%</td><td><code>{{ p.value }}</code></td></tr>
    {% endfor %}
  </table>
  {% else %}
  <div class="card muted">Sin información personal detectada en el entorno analizado.</div>
  {% endif %}

  <!-- ================= PERMISOS ================= -->
  <h2>Permisos de carpetas sensibles</h2>
  <table>
    <tr><th>Carpeta</th><th>Existe</th><th>Riesgo</th></tr>
    {% for p in result.permissions %}
    <tr>
      <td><code>{{ p.path }}</code></td>
      <td>{{ 'Sí' if p.exists else 'No' }}</td>
      <td><span class="badge {{ p.risk }}">{{ p.risk|upper }}</span></td>
    </tr>
    {% endfor %}
  </table>

  <!-- ================= RECOMENDACIONES ================= -->
  <h2>Recomendaciones</h2>
  {% if verdict and verdict.recommendations %}
  {% for rec in verdict.recommendations %}
  <div class="reco">
    <div class="n">{{ loop.index }}</div>
    <div class="t">{{ rec }}</div>
  </div>
  {% endfor %}
  {% else %}
  <div class="card">
    <div class="reco"><div class="n">1</div><div class="t">Sin hallazgos críticos: mantener la configuración actual y re-auditar periódicamente.</div></div>
    <div class="reco"><div class="n">2</div><div class="t">Limitar los puertos de servicios de IA solo a uso local (127.0.0.1) y no exponerlos a la red.</div></div>
    <div class="reco"><div class="n">3</div><div class="t">Rotar cualquier credencial de API almacenada en variables de entorno o archivos de configuración.</div></div>
  </div>
  {% endif %}

  <!-- ================= FOOTER ================= -->
  <div class="footer">
    <div><b>JZ Design Solutions</b> — P223 · Policía de IAs</div>
    <div>Generado automáticamente el {{ fecha }} · Modelo: {{ modelo }}</div>
    <div>Confidencial — no distribuir sin autorización</div>
  </div>

</div>
</body>
</html>
"""
)


# ---------------------------------------------------------------------------
# Graficos SVG (generados en Python para el template)
# ---------------------------------------------------------------------------

def _donut(result: AuditResult) -> str:
    """Donut SVG con la proporcion de procesos IA vs total.

    El circulo usa dasharray para dos segmentos y la leyenda va debajo
    (no al lado), evitando texto encimado dentro del SVG.
    """
    total = max(len(result.processes), 1)
    ia = len(result.ia_processes)
    resto = total - ia
    pct_ia = round(ia / total * 100, 1)
    r = 46.0
    c = 2 * 3.14159265 * r
    dash_ia = ia / total * c
    dash_resto = max(0.001, c - dash_ia)
    return f"""<svg width="230" height="170" viewBox="0 0 230 170" xmlns="http://www.w3.org/2000/svg">
      <circle cx="115" cy="70" r="{r}" fill="none" stroke="#242b3d" stroke-width="18"/>
      <circle cx="115" cy="70" r="{r}" fill="none" stroke="#d2bc93" stroke-width="18"
        stroke-dasharray="{dash_ia:.2f} {c:.2f}" transform="rotate(-90 115 70)"/>
      <circle cx="115" cy="70" r="{r}" fill="none" stroke="#10b981" stroke-width="18"
        stroke-dasharray="{dash_resto:.2f} {c:.2f}" stroke-dashoffset="{-dash_ia:.2f}"
        transform="rotate(-90 115 70)"/>
      <text x="115" y="66" text-anchor="middle" fill="#e8eaf0" font-size="18" font-weight="800">{pct_ia:.0f}%</text>
      <text x="115" y="82" text-anchor="middle" fill="#8b93a7" font-size="8">de procesos son IA</text>
      <g font-size="9" fill="#8b93a7">
        <rect x="40" y="128" width="10" height="10" rx="2" fill="#d2bc93"/>
        <text x="56" y="137">IA local ({ia})</text>
        <rect x="140" y="128" width="10" height="10" rx="2" fill="#10b981"/>
        <text x="156" y="137">Otros ({resto})</text>
      </g>
    </svg>"""


def _barras(result: AuditResult) -> str:
    """Barras horizontales SVG con los procesos IA (top 6 por nombre)."""
    procs = sorted(result.ia_processes, key=lambda p: len(" ".join(p.cmdline)), reverse=True)[:6]
    if not procs:
        return '<div class="card muted">Sin procesos de IA para graficar.</div>'
    h = 24
    ancho_max = 200
    filas = []
    for i, p in enumerate(procs):
        nombre = p.name[:26]
        # La barra escala con la longitud del nombre (visual estable)
        ancho = max(50, min(ancho_max, len(nombre) * 7 + 20))
        y = 12 + i * h
        filas.append(
            f'<rect x="0" y="{y}" width="{ancho}" height="14" rx="4" fill="#d2bc93"/>'
            f'<text x="{ancho + 8}" y="{y + 11}" fill="#8b93a7" font-size="8.5">{nombre}</text>'
        )
    alto = 12 + len(procs) * h + 4
    return f"""<svg width="230" height="{alto}" viewBox="0 0 230 {alto}" xmlns="http://www.w3.org/2000/svg">
      {''.join(filas)}
    </svg>"""


# Funciones expuestas al template de Jinja2
def _kpi_color(count: int) -> str:
    return "rojo" if count > 0 else "verde"


def render_html(result: AuditResult, verdict: AuditVerdict | None = None, modelo: str = "") -> str:
    fecha = datetime.now().strftime("%d/%m/%Y %H:%M")
    codigo = f"AIA-{datetime.now().strftime('%Y%m%d-%H%M')}"
    return _TEMPLATE.render(
        result=result,
        verdict=verdict,
        fecha=fecha,
        codigo=codigo,
        modelo=modelo or "deepseek-r1:7b (local)",
        donut=_donut,
        barras=_barras,
        kpi_color=_kpi_color,
    )


def save_report(
    result: AuditResult,
    output_dir: Path,
    verdict: AuditVerdict | None = None,
    as_pdf: bool = False,
    modelo: str = "",
) -> Path:
    """Genera el reporte en output_dir y devuelve la ruta del archivo."""
    output_dir.mkdir(parents=True, exist_ok=True)
    if as_pdf:
        from playwright.sync_api import sync_playwright

        html = render_html(result, verdict, modelo=modelo)
        target = output_dir / f"auditoria_{result.timestamp[:19].replace(':', '-')}.pdf"
        with sync_playwright() as pw:
            browser = pw.chromium.launch()
            page = browser.new_page()
            page.set_content(html, wait_until="networkidle")
            page.pdf(path=str(target), format="A4", print_background=True,
                     margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
            browser.close()
        return target

    target = output_dir / f"auditoria_{result.timestamp[:19].replace(':', '-')}.html"
    target.write_text(render_html(result, verdict, modelo=modelo), encoding="utf-8")
    return target
