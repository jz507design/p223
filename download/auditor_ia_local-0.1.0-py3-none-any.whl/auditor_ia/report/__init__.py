"""Generacion de reportes (HTML/PDF)."""
