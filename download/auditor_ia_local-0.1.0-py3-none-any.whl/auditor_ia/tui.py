"""Interfaz de terminal interactiva (TUI) de P223 — Policia de IAs.

Menu de colores con rich para demo y uso diario. Incluye: escaneo rapido,
auditoria con el modelo local (Ollama), panel web, historial, deteccion de
PII y el interceptor de trafico.

Uso:
    p223 tui
"""

from __future__ import annotations

import subprocess
import sys
import webbrowser

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

from auditor_ia.config import REPORTS_DIR, Settings
from auditor_ia.db.historial import load_history, save_audit
from auditor_ia.i18n import LANGS, elegir_idioma, tr
from auditor_ia.report.generador import save_report
from auditor_ia.scanner.pii import PiiDetector
from auditor_ia.scanner.runner import run_scan, summarize_result
from auditor_ia.semantic.motor import OllamaUnavailableError, audit_with_ollama

# Paleta consistente con el reporte HTML (semáforo)
COLOR_BAJO = "green"
COLOR_MEDIO = "yellow"
COLOR_ALTO = "red"

console = Console()

# Idioma activo de la sesión (se puede cambiar con la opción 8)
_lang: str = "es"


def _tr(key: str, **kwargs: object) -> str:
    return tr(_lang, key, **kwargs)


def _banner() -> None:
    """Cabecera de la TUI con el nombre del producto."""
    titulo = Text()
    titulo.append(f"🛡️  {_tr('tui_nombre')}", style="bold cyan")
    titulo.append(f"  {_tr('tui_subtitulo')}", style="dim")
    console.print(
        Panel(
            titulo,
            subtitle=_tr("tui_pie"),
            box=box.DOUBLE,
            border_style="cyan",
        )
    )


def _risk_style(riesgo: str) -> str:
    """Mapa riesgo -> estilo de color (semáforo)."""
    return {
        "bajo": COLOR_BAJO,
        "medio": COLOR_MEDIO,
        "alto": COLOR_ALTO,
    }.get(riesgo, "white")


def _menu() -> str:
    """Muestra las opciones y devuelve la elección del usuario."""
    tabla = Table(box=box.SIMPLE_HEAD, show_header=False, title=_tr("tui_menu"))
    tabla.add_column(_tr("tui_opcion"), style="bold cyan", width=10)
    tabla.add_column(_tr("tui_accion"))
    opciones = [
        ("1", _tr("tui_op1")),
        ("2", _tr("tui_op2")),
        ("3", _tr("tui_op3")),
        ("4", _tr("tui_op4")),
        ("5", _tr("tui_op5")),
        ("6", _tr("tui_op6")),
        ("7", _tr("tui_op7")),
        ("8", _tr("tui_op8")),
        ("0", _tr("tui_salir")),
    ]
    for num, desc in opciones:
        tabla.add_row(num, desc)
    console.print(tabla)
    return Prompt.ask(_tr("tui_selecciona"), choices=[o[0] for o in opciones], default="0")


def _tabla_resultado(result) -> Table:
    """Construye la tabla resumen del escaneo para mostrar en pantalla."""
    tabla = Table(title=_tr("tui_resumen"), box=box.ROUNDED)
    tabla.add_column(_tr("tui_metrica"), style="bold")
    tabla.add_column(_tr("tui_valor"))
    tabla.add_row(_tr("tui_total_proc"), str(len(result.processes)))
    tabla.add_row(_tr("tui_proc_ia"), str(len(result.ia_processes)))
    tabla.add_row(_tr("tui_puertos_ia"), str(len(result.open_ports)))
    tabla.add_row(_tr("tui_secretos"), str(len(result.secrets)))
    tabla.add_row(_tr("tui_riesgos_altos"), str(result.high_risk_count))

    if result.ia_processes:
        tabla.add_section()
        for proc in result.ia_processes[:8]:
            tabla.add_row(f"IA · PID {proc.pid}", f"{proc.name} — {' '.join(proc.cmdline)[:60]}")
    if result.open_ports:
        tabla.add_section()
        for port in result.open_ports:
            tabla.add_row(f"Puerto {port.port}", f"{port.service} [abierto]")
    return tabla


def _ejecutar_escaneo(silencioso: bool = False) -> object | None:
    """Ejecuta un escaneo de entorno y muestra el resumen.

    Devuelve el resultado (para encadenar auditoría) o None si falla.
    """
    settings = Settings.from_env()
    try:
        with console.status(f"[bold cyan]{_tr('tui_escaneando')}", spinner="dots12"):
            result = run_scan(settings)
    except Exception as exc:  # noqa: BLE001 — la TUI no debe reventar ante un fallo de escaneo
        console.print(f"[bold red]{_tr('tui_error_escaneo')}:[/] {exc}")
        return None

    if not silencioso:
        console.print(_tabla_resultado(result))
    return result


def _op_escaneo() -> None:
    """Opción 1: escaneo rápido y guardado del reporte."""
    result = _ejecutar_escaneo()
    if result is None:
        return
    settings = Settings.from_env()
    report_path = save_report(result, REPORTS_DIR,
                              as_pdf=(settings.report_format == "pdf"),
                              modelo=settings.auditor_model)
    save_audit(settings.db_path, result, report_path=str(report_path))
    console.print(f"[green]✓ {_tr('tui_reporte_gen')}:[/] {report_path}")


def _op_auditoria(ver_pdf: bool = False) -> None:
    """Opción 2: escaneo + veredicto del modelo local (Ollama).

    El resultado SIEMPRE se muestra en la terminal; ver_pdf=True fuerza
    el reporte en PDF (opción 3 del menú).
    """
    result = _ejecutar_escaneo(silencioso=False)
    if result is None:
        return
    settings = Settings.from_env()
    summary = summarize_result(result, lang=_lang)

    console.print(f"[bold cyan]{_tr('tui_veredicto')}")
    try:
        verdict = audit_with_ollama(settings, summary)
    except OllamaUnavailableError as exc:
        console.print(f"[bold red]{_tr('tui_ollama_no')}:[/] {exc}")
        console.print(f"[yellow]{_tr('tui_sin_veredicto')}[/]")
        verdict = None

    if verdict:
        color = _risk_style(verdict.risk_level)
        console.print(
            Panel(
                Text(f"{verdict.summary}", style="bold"),
                title=_tr("tui_veredicto_titulo", riesgo=verdict.risk_level.upper()),
                border_style=color,
            )
        )
        if verdict.recommendations:
            recs = Table(box=box.SIMPLE_HEAD, title=_tr("tui_recomendaciones"))
            recs.add_column("#", width=4)
            recs.add_column(_tr("tui_recomendacion"))
            for i, rec in enumerate(verdict.recommendations, 1):
                recs.add_row(str(i), rec)
            console.print(recs)

    report_path = save_report(
        result,
        REPORTS_DIR,
        verdict=verdict,
        as_pdf=ver_pdf,
        modelo=settings.auditor_model,
    )
    save_audit(
        settings.db_path,
        result,
        risk_level=verdict.risk_level if verdict else "",
        summary=verdict.summary if verdict else "",
        recommendations=verdict.recommendations if verdict else None,
        report_path=str(report_path),
    )
    tipo = "PDF" if ver_pdf else "HTML"
    console.print(f"[green]✓ {_tr('tui_reporte_guardado', tipo=tipo)}:[/] {report_path}")


def _op_pdf() -> None:
    """Opción 3: auditoría completa con reporte PDF premium.

    Muestra el resultado en la terminal y genera el PDF para el cliente.
    """
    console.print(f"[bold cyan]{_tr('tui_pdf_premium')}")
    _op_auditoria(ver_pdf=True)


def _op_web() -> None:
    """Opción 4: arranca el panel web y abre el navegador."""
    settings = Settings.from_env()
    if not Confirm.ask(_tr("tui_abrir_panel"), default=True):
        return
    puerto = "8000"
    # Se lanza uvicorn en un proceso separado para que la TUI siga viva.
    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "uvicorn",
            "auditor_ia.web.app:app",
            "--host",
            "127.0.0.1",
            "--port",
            puerto,
        ],
        cwd=str(settings.db_path.parent),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    console.print(f"[green]✓ {_tr('tui_panel_on', puerto=puerto)}[/] (PID {proc.pid})")
    console.print(f"[dim]{_tr('tui_detener_panel', pid=proc.pid)}[/]")
    webbrowser.open(f"http://127.0.0.1:{puerto}")


def _op_historial() -> None:
    """Opción 5: historial de auditorías."""
    settings = Settings.from_env()
    rows = load_history(settings.db_path, limit=50)
    if not rows:
        console.print(f"[yellow]{_tr('tui_hist_vacio')}[/]")
        return
    tabla = Table(title=_tr("tui_historial"), box=box.ROUNDED)
    tabla.add_column(_tr("tui_id"), width=4)
    tabla.add_column(_tr("tui_fecha"), width=26)
    tabla.add_column(_tr("tui_riesgo"), width=10)
    tabla.add_column(_tr("tui_reporte"))
    for row in rows:
        riesgo = row["risk_level"] or "n/d"
        estilo = _risk_style(riesgo)
        tabla.add_row(
            str(row["id"]),
            row["timestamp"][:19],
            f"[{estilo}] {riesgo.upper()} [/]",
            row["report_path"] or "",
        )
    console.print(tabla)


def _op_pii() -> None:
    """Opción 6: detectar y anonimizar PII en un texto."""
    console.print(f"[cyan]{_tr('tui_pii_pega')}[/]")
    texto = Prompt.ask(_tr("tui_pii_texto"))
    if not texto.strip():
        console.print(f"[yellow]{_tr('tui_pii_vacio')}[/]")
        return
    with console.status(f"[bold cyan]{_tr('tui_pii_analizando')}", spinner="dots"):
        detector = PiiDetector()
        analisis = detector.anonymize(texto)

    if not analisis.findings:
        console.print(f"[green]✓ {_tr('tui_pii_sin')}[/]")
        return

    tabla = Table(title=f"{_tr('tui_pii_titulo')}: {analisis.count}", box=box.ROUNDED)
    tabla.add_column(_tr("tui_pii_entidad"), style="bold yellow")
    tabla.add_column(_tr("tui_pii_conf"))
    tabla.add_column(_tr("tui_pii_valor"))
    for f in sorted(analisis.findings, key=lambda x: x.start):
        tabla.add_row(f.entity, f"{f.score:.0%}", f.value)
    console.print(tabla)
    if Confirm.ask(_tr("tui_pii_mostrar"), default=False):
        console.print(Panel(analisis.anonymized, title=_tr("tui_pii_anonimizado")))


def _op_proxy() -> None:
    """Opción 7: interceptor de tráfico con mitmproxy."""
    if not Confirm.ask(_tr("tui_proxy_conf"), default=False):
        return
    console.print(f"[yellow]{_tr('tui_proxy_conf_sys')}[/]")
    console.print(f"[yellow]{_tr('tui_proxy_ctrl_c')}[/]")
    import asyncio

    import mitmproxy.options
    from mitmproxy.tools.dump import DumpMaster

    from auditor_ia.interceptor.interceptor import InterceptorHooks
    from auditor_ia.interceptor.registro import save_alerts

    async def run_proxy() -> None:
        opts = mitmproxy.options.Options(listen_host="127.0.0.1", listen_port=8080)
        master = DumpMaster(opts)
        hooks = InterceptorHooks()
        master.addons.add(hooks)
        try:
            await master.run()
        except KeyboardInterrupt:
            pass
        finally:
            master.shutdown()
            if hooks.alerts:
                target = save_alerts(hooks.alerts, REPORTS_DIR / "alertas")
                console.print(f"[yellow]{_tr('tui_proxy_alertas')}: {len(hooks.alerts)}[/] → {target}")
                for alert in hooks.alerts:
                    color = _risk_style(alert.risk)
                    console.print(f"  [{color}]{alert.risk.upper():6}[/] {alert.host} {alert.method} {alert.path} — {alert.reason}")
            else:
                console.print(f"[green]{_tr('tui_proxy_sin')}[/]")

    asyncio.run(run_proxy())


def _op_idioma() -> None:
    """Opción 8: cambiar el idioma de la sesión (es/en)."""
    global _lang
    nuevo = elegir_idioma(f"{_tr('selecciona_lang')} (actual: {_lang})")
    if nuevo not in LANGS:
        console.print(_tr("tui_cambiando_lang", lang=nuevo))
        return
    _lang = nuevo
    console.print(f"[green]✓ Idioma: {_lang}[/]")


def main(lang: str | None = None) -> int:
    """Bucle principal de la TUI.

    ``lang`` puede venir del CLI (--lang). Si no se pasa, se pregunta
    interactivamente al inicio.
    """
    global _lang
    if lang in LANGS:
        _lang = lang
    else:
        _lang = elegir_idioma()
    _banner()
    while True:
        try:
            opcion = _menu()
        except (EOFError, KeyboardInterrupt):
            console.print(f"\n[yellow]{_tr('tui_saliendo')}[/]")
            return 0

        if opcion == "0":
            console.print(f"[green]{_tr('tui_hasta')}[/]")
            return 0
        if opcion == "1":
            _op_escaneo()
        elif opcion == "2":
            _op_auditoria()
        elif opcion == "3":
            _op_pdf()
        elif opcion == "4":
            _op_web()
        elif opcion == "5":
            _op_historial()
        elif opcion == "6":
            _op_pii()
        elif opcion == "7":
            _op_proxy()
        elif opcion == "8":
            _op_idioma()

        console.print()


if __name__ == "__main__":
    raise SystemExit(main())
